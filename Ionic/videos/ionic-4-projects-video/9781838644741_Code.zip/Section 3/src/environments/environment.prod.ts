export const environment = {
    production: true,
    googleApiKey: 'AIzaSyCnhfBvjx6BS92xLwI0fX35e0Vec4ZpGiE'
};
