// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: false,
    firebaseConfig: {
        apiKey: 'AIzaSyBaaqUEfGPfnmpsPWHUYmD_myo2MQG5RTs',
        authDomain: 'stockcheck-app.firebaseapp.com',
        databaseURL: 'https://stockcheck-app.firebaseio.com',
        projectId: 'stockcheck-app',
        storageBucket: 'stockcheck-app.appspot.com',
        messagingSenderId: '717772510387',
        appId: '1:717772510387:web:3b5dd89f2f215f78',
        vapidKey:
            'BEdPjtgNKH2GZ3lYG4LLD41lIbzqYxfeG9MUXXjk0y6pjnHn9LrnuJ2TDUlgqwGjFfhVAHtsixidd2-Fqe2513w'
    }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
