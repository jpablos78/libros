var myArray = [5, 10, 15, 20, 25];
for (var _i = 0, myArray_1 = myArray; _i < myArray_1.length; _i++) {
    var item = myArray_1[_i];
    console.log(item);
}
