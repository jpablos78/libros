var author = {
    firstName: 'Aki',
    lastName: 'Iskandar',
    topics: ['Angular', 'JavaScript', 'TypeScript', 'Bootstrap', 'Node'],
    cities: ['Calgary', 'Cleveland'],
    publisher: 'Packt'
};
var fName = author.firstName;
var lName = author.lastName;
var pubName = author.publisher;
console.log(pubName);
var firstName = author.firstName, lastName = author.lastName, publisher = author.publisher;
console.log(firstName);
