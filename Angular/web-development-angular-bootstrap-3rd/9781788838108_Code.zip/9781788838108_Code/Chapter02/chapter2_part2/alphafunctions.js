"use strict";
exports.__esModule = true;
function alpha1() {
    console.log("Alpha 1 was called");
}
exports.alpha1 = alpha1;
function alpha2() {
    console.log("Alpha 2 was called");
}
exports.alpha2 = alpha2;
