function alpha1() {
  console.log("Alpha 1 was called");
}
function alpha2() {
  console.log("Alpha 2 was called");
}
export {alpha1, alpha2};