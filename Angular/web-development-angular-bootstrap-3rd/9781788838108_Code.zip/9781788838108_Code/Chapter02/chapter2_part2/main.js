"use strict";
exports.__esModule = true;
var alphafunctions_1 = require("./alphafunctions");
alphafunctions_1.alpha1(); //  "Alpha 1 was called" is written to the console
