let myArray = [5, 10, 15, 20, 25];
  for (var item of myArray) {
  console.log(item);
}