import {alpha1, alpha2} from './alphafunctions';  
alpha1();  //  "Alpha 1 was called" is written to the console