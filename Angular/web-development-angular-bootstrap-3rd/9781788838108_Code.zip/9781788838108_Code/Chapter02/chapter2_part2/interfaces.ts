/* Example #2 - Interfaces */
class Animal implements Species {
}  
interface Species {
  name: string;
  isExtinct: boolean;
} 
