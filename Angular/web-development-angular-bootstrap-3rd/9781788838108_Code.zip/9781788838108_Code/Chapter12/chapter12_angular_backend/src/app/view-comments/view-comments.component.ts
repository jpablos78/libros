import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-comments',
  templateUrl: './view-comments.component.html',
  styleUrls: ['./view-comments.component.scss']
})
export class ViewCommentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
