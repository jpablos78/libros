export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyDW0YvxtY3sGH-sWr1u8m9Tyk4QMS5Ho6U",
    authDomain: "photosdb-9cbec.firebaseapp.com",
    databaseURL: "https://photosdb-9cbec.firebaseio.com",
    projectId: "photosdb-9cbec",
    storageBucket: "photosdb-9cbec.appspot.com",
    messagingSenderId: "19978618750"
  }
};