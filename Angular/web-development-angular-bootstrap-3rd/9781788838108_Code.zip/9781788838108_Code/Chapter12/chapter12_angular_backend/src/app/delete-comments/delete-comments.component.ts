import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-comments',
  templateUrl: './delete-comments.component.html',
  styleUrls: ['./delete-comments.component.scss']
})
export class DeleteCommentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
