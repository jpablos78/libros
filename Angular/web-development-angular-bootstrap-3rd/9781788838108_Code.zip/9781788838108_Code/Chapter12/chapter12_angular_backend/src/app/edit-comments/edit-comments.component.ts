import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-comments',
  templateUrl: './edit-comments.component.html',
  styleUrls: ['./edit-comments.component.scss']
})
export class EditCommentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
