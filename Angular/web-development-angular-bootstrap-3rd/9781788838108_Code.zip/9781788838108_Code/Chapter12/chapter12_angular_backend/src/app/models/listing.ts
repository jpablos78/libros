export interface Listing {
 id: number;
 userId: number;
 title: string;
 description: string;
 status: string;
 price: number;
 active: boolean;
}