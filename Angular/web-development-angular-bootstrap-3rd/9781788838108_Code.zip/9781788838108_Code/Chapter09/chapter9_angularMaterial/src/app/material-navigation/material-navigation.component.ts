import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-material-navigation',
  templateUrl: './material-navigation.component.html',
  styleUrls: ['./material-navigation.component.scss']
})
export class MaterialNavigationComponent implements OnInit {

  title = "Angular Material";
  
  constructor() { }

  ngOnInit() {
  }



}
