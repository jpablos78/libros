import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bootstrap-material-combo',
  templateUrl: './bootstrap-material-combo.component.html',
  styleUrls: ['./bootstrap-material-combo.component.scss']
})
export class BootstrapMaterialComboComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
