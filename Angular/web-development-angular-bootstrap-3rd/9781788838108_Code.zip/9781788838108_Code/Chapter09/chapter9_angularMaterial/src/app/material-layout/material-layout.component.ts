import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-material-layout',
  templateUrl: './material-layout.component.html',
  styleUrls: ['./material-layout.component.scss']
})
export class MaterialLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
