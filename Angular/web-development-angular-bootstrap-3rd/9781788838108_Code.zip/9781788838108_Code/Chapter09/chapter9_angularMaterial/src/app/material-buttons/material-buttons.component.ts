import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-material-buttons',
  templateUrl: './material-buttons.component.html',
  styleUrls: ['./material-buttons.component.scss']
})
export class MaterialButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
