import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-listing',
  templateUrl: './create-listing.component.html',
  styleUrls: ['./create-listing.component.css']
})
export class CreateListingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
