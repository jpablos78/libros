export interface Photo {
}
