import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-photo-listing',
  templateUrl: './photo-listing.component.html',
  styleUrls: ['./photo-listing.component.scss']
})
export class PhotoListingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
