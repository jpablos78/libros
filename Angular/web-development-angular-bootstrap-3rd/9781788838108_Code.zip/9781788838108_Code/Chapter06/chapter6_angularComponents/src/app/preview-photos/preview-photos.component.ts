import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preview-photos',
  templateUrl: './preview-photos.component.html',
  styleUrls: ['./preview-photos.component.scss']
})
export class PreviewPhotosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
