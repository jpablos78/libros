import {Component} from '@angular/core';

@Component({
    selector: 'section',
    templateUrl: 'src/app/section/section.component.html',
    styleUrls: ['src/app/section/section.component.css']
})
export class SectionComponent {
    username: string;
}
