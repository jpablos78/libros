import {Component} from '@angular/core';

@Component({
    selector: 'section',
    templateUrl: './section.component.html'
})
export class SectionComponent {
    username: string;
}
