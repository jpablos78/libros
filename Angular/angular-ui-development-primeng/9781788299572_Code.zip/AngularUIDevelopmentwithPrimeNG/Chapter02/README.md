### Code samples for chapter 2

Every chapter has section driven subfolders with README files that contain all required instructions how to run demo applications. All demo applications in the book were developed with Angular 4 and PrimeNG 4.

__Happy Learning, Go-ahead!__ :dash: