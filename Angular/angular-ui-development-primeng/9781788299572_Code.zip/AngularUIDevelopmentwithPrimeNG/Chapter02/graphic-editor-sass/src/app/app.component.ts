import {Component} from '@angular/core';

@Component({
    selector: 'ge-app',
    templateUrl: 'app.component.html'
})
export class AppComponent {
}
