enum PaletteMode {
    Select,
    Marquee
}

export default PaletteMode;
