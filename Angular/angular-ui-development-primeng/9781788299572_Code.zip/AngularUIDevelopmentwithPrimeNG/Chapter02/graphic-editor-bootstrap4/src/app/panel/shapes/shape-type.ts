enum ShapeType {
    Task,
    Event,
    Connector
}

export default ShapeType;
