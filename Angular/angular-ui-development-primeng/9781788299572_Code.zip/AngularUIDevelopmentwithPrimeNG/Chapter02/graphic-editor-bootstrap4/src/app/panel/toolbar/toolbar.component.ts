import {Component} from '@angular/core';

@Component({
    selector: 'ge-toolbar',
    templateUrl: 'toolbar.component.html'
})
export class ToolbarComponent {
}
