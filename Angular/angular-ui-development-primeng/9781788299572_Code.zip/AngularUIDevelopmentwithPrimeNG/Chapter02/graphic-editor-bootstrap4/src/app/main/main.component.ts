import {Component} from '@angular/core';

@Component({
    selector: 'ge-main',
    templateUrl: 'main.component.html'
})
export class MainComponent {
}
