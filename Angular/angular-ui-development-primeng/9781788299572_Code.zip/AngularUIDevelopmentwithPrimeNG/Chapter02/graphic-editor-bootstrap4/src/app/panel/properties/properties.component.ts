import {Component} from '@angular/core';

@Component({
    selector: 'ge-properties',
    templateUrl: 'properties.component.html'
})
export class PropertiesComponent {
}
