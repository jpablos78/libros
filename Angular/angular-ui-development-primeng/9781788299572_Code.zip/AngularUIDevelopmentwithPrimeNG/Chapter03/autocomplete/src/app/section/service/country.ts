interface Country {
    name: any;
    dial_code?: any;
    code?: any;
}

export default Country;
