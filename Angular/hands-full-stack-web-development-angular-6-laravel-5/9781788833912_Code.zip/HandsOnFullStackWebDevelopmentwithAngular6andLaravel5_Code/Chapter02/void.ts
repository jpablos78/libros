function myVoidExample(firstName: string, lastName: string): void {
    const name = firstName + lastName;
}
console.log(myVoidExample('Jhonny ', 'Cash'));