
import { MyBand } from './export';
console.log( new MyBand(['ZZ Top', 'Motorhead'], 3));