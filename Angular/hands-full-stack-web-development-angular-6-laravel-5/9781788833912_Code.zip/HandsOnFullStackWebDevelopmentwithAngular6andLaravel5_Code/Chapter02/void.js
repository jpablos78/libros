function myVoidExample(firstName, lastName) {
    return firstName + lastName;
}
console.log(myVoidExample('Jhonny ', 'Cash'));
